import boto3
from datetime import datetime, timedelta
from stat import S_ISREG

def lambda_handler(event, context):
    athena = boto3.client('athena')

    table_fields_dpt = ['departamento']
    table_fields_mcp = ['municipio']
    

    table_name_dpt = "precipts_deptm"
    table_name_mcp = "precipts_muncp"

    create_table_if_not_exist(table_fields_dpt, table_name_dpt, athena)
    create_table_if_not_exist(table_fields_mcp, table_name_mcp, athena)

    date_key = datetime.now() - timedelta(days=1)

    for hour in range(24):  
        hour_key = f"{date_key}{hour:02d}"
        execute_athena_query(table_fields_dpt, athena, "departamento", hour_key)
        execute_athena_query(table_fields_mcp, athena, "municipio", hour_key)


  


def execute_athena_query(table_name, athena, territorio, hour_key):
    
    folder_name = "precipitaciones_diarias"
    output_location = 's3://athena-query-results-390403866377/'
    database = 'precipitaciones_prueba'

    # Calculate the date for the previous day
    previous_day = datetime.now() - timedelta(days=1)
    date_key = previous_day.strftime('%Y%m%d')

    try:
        
        query = f"""
            INSERT INTO {table_name}
            SELECT {territorio}, sum(cast(valorobservado as double)) total_lluvia_registrada, fct_dt
            FROM 
            (
            SELECT departamento, valorobservado, substring(dt_key, 1,8) fct_dt
            FROM "precipitaciones_prueba"."precipitaciones_diarias"
            WHERE dt_key = '{hour_key}'   
            )
        """
            
        # Start query execution
        response = athena.start_query_execution(
            QueryString=query,
            QueryExecutionContext={'Database': database},
            ResultConfiguration={'OutputLocation': output_location}
        )
        query_execution_id = response['QueryExecutionId']
        print(f"Started partition addition for hour {hour_key}, QueryExecutionId: {query_execution_id}")
        
        # Wait for the query to complete
        while True:
            query_status = athena.get_query_execution(QueryExecutionId=query_execution_id)
            status = query_status['QueryExecution']['Status']['State']
            if status in ['SUCCEEDED', 'FAILED', 'CANCELLED']:
                break

        if status != 'SUCCEEDED':
            print(f"Query for hour {hour_key} failed with status: {status}")
            raise Exception(f"Failed to add partition for {hour_key}")

        print("All partitions added successfully.")
        return True

    except Exception as e:
        print(f"Error adding partitions in Athena: {str(e)}")
        return False


def create_table_if_not_exist(table_fields, table_name, athena_client):
    bucket_name = "s3-raw-data-precipitation-model"
    s3_route = f"s3://{bucket_name}/{table_name}"
   
    catalog_data_base = "precipitaciones_prueba"
    
    metadata = ', '.join([f'`{campo}` String' for campo in table_fields]) + ', `total_lluvia_registrada` String'
    
    create_table_query = f"""
    CREATE EXTERNAL TABLE IF NOT EXISTS `{catalog_data_base}`.`{table_name}` (
        {metadata}
    )
    PARTITIONED BY (
        `fct_dt` string
    )
    ROW FORMAT SERDE 
      'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' 
    WITH SERDEPROPERTIES (
      'compression'='snappy'
    )
    STORED AS INPUTFORMAT 
      'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' 
    OUTPUTFORMAT 
      'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
    LOCATION
      '{s3_route}'
    """
    
    output_location = f's3://athena-query-results-390403866377/'
    
    try:
        response = athena_client.start_query_execution(
            QueryString=create_table_query,
            QueryExecutionContext={'Database': catalog_data_base},
            ResultConfiguration={'OutputLocation': output_location}
        )
        query_execution_id = response['QueryExecutionId']
        print(f"Athena table creation started, QueryExecutionId: {query_execution_id}")
    except Exception as e:
        print(f"Error creating table in Athena: {str(e)}")
    
    return True