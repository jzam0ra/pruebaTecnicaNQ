import json
import boto3
from datetime import datetime

def lambda_handler(event, context):
    athena = boto3.client('athena')

    folder_name = "precipitaciones_diarias"

    dateloadhour = datetime.now().strftime('%Y%m%d%H')

    query = f"""
        alter table {folder_name.replace("-","_")}
        add if not exists partition (dt_key='{dateloadhour}')
        location 's3://s3-raw-data-precipitation-model/{folder_name}/dt_key={dateloadhour}/'
    """
    output_location = f's3://athena-query-results-390403866377/'
    database = 'precipitaciones_prueba'
    
    try:
        response = athena.start_query_execution(
            QueryString=query,
            QueryExecutionContext={'Database': database},
            ResultConfiguration={'OutputLocation': output_location}
        )
        query_execution_id = response['QueryExecutionId']
        print(f"Athena partition addition started, QueryExecutionId: {query_execution_id}")
        while True:
            query_status = athena.get_query_execution(QueryExecutionId=query_execution_id)
            status = query_status['QueryExecution']['Status']['State']
            if status in ['SUCCEEDED', 'FAILED', 'CANCELLED'] :
                break

        if status == 'SUCCEEDED':
            return True
    except Exception as e:
        print(f"Error adding partitions in Athena: {str(e)}")
    
