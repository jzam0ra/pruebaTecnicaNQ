import json
import pandas as pd
import requests
import io
from io import BytesIO
import boto3

def lambda_handler(event, context):
    s3_client = boto3.client('s3')
    base_url = 'https://www.datos.gov.co/resource/s54a-sgyg.csv'

    start_date = '2024-12-18T00:00:00.000'
    end_date = '2024-12-21T00:00:00.000'

    url = f"{base_url}?$limit=1000000&$where=fechaobservacion between '{start_date}' and '{end_date}'"

    response = requests.get(url)

    if response.status_code == 200:
        data = pd.read_csv(io.StringIO(response.text), sep=",", dtype=str)

        data['fechaobservacion'] = pd.to_datetime(data['fechaobservacion'])
        data['dt_key'] = data['fechaobservacion'].dt.strftime('%Y%m%d%H')
        data['fechaobservacion'] = data['fechaobservacion'].astype(str)

        for date in data['dt_key'].unique():
            df_now = data.loc[data['dt_key'] == date]
            df_now.drop(columns=['dt_key'])

            parquet_buffer = BytesIO()
            df_now.to_parquet(parquet_buffer, index = False, compression='snappy')

            s3_key = f"precipitaciones_diarias/dt_key={date}/part-00000.snappy.parquet"

            try:
                s3_client.put_object(Bucket='s3-raw-data-precipitation-model',Key=s3_key, Body=parquet_buffer.getvalue())
            except Exception as e:
                print(f"no se pudo escribir en parquet: {e}")

    else:
        print(f"Failed to fetch data. HTTP Status Code: {response.status_code}")






"""
#!/usr/bin/env python

# make sure to install these packages before running:
# pip install pandas
# pip install sodapy

import pandas as pd
from sodapy import Socrata

# Unauthenticated client only works with public data sets. Note 'None'
# in place of application token, and no username or password:
client = Socrata("www.datos.gov.co", None)

# Example authenticated client (needed for non-public datasets):
# client = Socrata(www.datos.gov.co,
#                  MyAppToken,
#                  username="user@example.com",
#                  password="AFakePassword")

# First 2000 results, returned as JSON from API / converted to Python list of
# dictionaries by sodapy.
results = client.get("s54a-sgyg", limit=1000000)

# Convert to pandas DataFrame
results_df = pd.DataFrame.from_records(results)
print(results_df)
"""